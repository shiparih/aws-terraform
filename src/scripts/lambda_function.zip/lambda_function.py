import boto3
import datetime
import redis

# Initialize AWS SDK clients
s3_client = boto3.client('s3')


# Initialize Redis client
redis_client = redis.StrictRedis(host='rediscluster.fri3lk.ng.0001.use2.cache.amazonaws.com', 
                                    port=6379,  password=None, decode_responses=True)


def lambda_handler(event, context):
    # Get the S3 bucket and object information from the event
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    object_key = event['Records'][0]['s3']['object']['key']
    print("test 1")
    creation_timestamp = event['Records'][0]['eventTime']

    # Get the file name from the object key
    file_name = object_key.split('/')[-1]

    # Get the current timestamp
    print("creation_timestamp: ", creation_timestamp)

    # Create the key-value pair in the format "<filename>:<creation_timestamp>"
    key_value_pair = f"{file_name}:{creation_timestamp}"

    print(key_value_pair)
    # Write the key-value pair to the Redis cluster
    try:
        print("test_run slp: ", redis_client)
        redis_client.set(file_name, creation_timestamp)
        #redis_client.set(key_value_pair)

        print("Successfully written to Elasticache:", key_value_pair)

    except Exception as e:
        print("Error writing to Elasticache:", str(e))

    return {
        'statusCode': 200,
        'body': 'File upload processed successfully!'
    }
